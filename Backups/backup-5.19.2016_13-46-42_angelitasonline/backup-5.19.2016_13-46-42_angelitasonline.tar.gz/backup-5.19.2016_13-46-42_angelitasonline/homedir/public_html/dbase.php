<?
$linkID = mysql_connect("localhost","angelita_us548", "3r{o#vQeX8GH")
        or exit("Could not connect");

mysql_select_db ("angelita_bd548");

?>