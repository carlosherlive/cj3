<?
include("_main.header.php");
?>

<table width="720" height="400" border="0" align="center" cellpadding="0" cellspacing="0">

  <tr>

    <td align="center" valign="middle"><table width="320" border="0" cellspacing="0" cellpadding="0">

      <tr>

        <td><p class="message">Contact information<br>

        </p>

          </td>

      </tr>

      <tr>

        <td>&nbsp;</td>

      </tr>

    </table></td>

  </tr>

</table>

<br>

<?
include("_main.footer.php");
?>

