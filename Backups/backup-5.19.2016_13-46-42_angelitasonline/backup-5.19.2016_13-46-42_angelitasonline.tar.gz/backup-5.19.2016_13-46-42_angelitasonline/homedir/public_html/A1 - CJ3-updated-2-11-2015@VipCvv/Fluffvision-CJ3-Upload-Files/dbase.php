<?
$linkID = mysql_connect("localhost","Database-Username", "password")
        or exit("Could not connect");

mysql_select_db ("Database-Name");

?>