<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Untitled Document</title>
<style type="text/css">
<!--

.footer {
	font-size: 10px;
	font-weight: bold;
	color: #FFFFFF;
	font-family: Arial, Helvetica, sans-serif;
}

-->
</style></head>

<body>
<div style="footer" align="center" valign="top">
  <table width="100%" border="0">
    <tr>
      <td><div align="center" valign="top">
        <table width="100%" height="38" border="0" background="../../images/footer-bg-1.png">
          <tr>
            <td><div align="center" valign="bottom">
              <p class="footer">Copyright &copy; <? echo $copyrightYear; ?> &nbsp;<a href="../../index.php" target="_blank"><? echo $copyright; ?></a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href="../../admin/index.php" target="_blank"><strong>ADMIN PANEL</strong></a> &nbsp;| &nbsp;&nbsp;<a href="../../index.php">SITE HOME</a>&nbsp;&nbsp;&nbsp;|&nbsp;&nbsp; <a href="../../login_model.php">PERFORMERS</a>&nbsp;&nbsp; | &nbsp;&nbsp;<a href="../../law.php" target="_self">18 U.S.C. 2257  Record-Keeping  Requirements  Compliance Statement</a></span>
              </div></td>
          </tr>
        </table>
        <table width="100%" height="69" border="0" background="../../images/footer-bg-2.png">
          <tr>
            <td height="65"><div align="center"></div></td>
          </tr>
        </table>
        <table width="100%" height="30" border="0" bgcolor="#660000" id="very-bottom-footer-table">
          <tr>
            <td><div align="center"></div></td>
          </tr>
        </table>
      </div></td>
    </tr>
  </table>
</div>
</body>
</html>
