<? if (isset($_COOKIE["usertype"])){

	
    include("_main.header.logged.in.php");	
	
			  	  

	} else {
 
		 
	include("_main.header.php");		  
			  

	} ?>

  <style type="text/css">
<!--
.law {font-size: 16px; color: #000000; }

-->
  </style>
  
  
</p>
<div class="law" align="center">
  <p>&nbsp;</p>
  <p>&nbsp;</p>
  <table width="900" height="449" border="0" cellpadding="40" cellspacing="3" background="images/white-bg-Law.png">
    <tr>
      <td><div align="center">
        <p>&nbsp;</p>
        <div>
          <div>
            <p class="law">In compliance with the Federal Labeling and Record-Keeping Law   (also known as 18 U.S.C. 2257), all models located within our domain   were 18 years of age or older during the time of photography. All   models' proof of age is held by the custodian of records, which is   listed below, organized by producer. All content and images are in full   compliance with the requirements of 18 U.S.C. 2257 and associated   regulations.</p>
            <span class="law"><br>
            </span>
            <p class="law">Your Website Name </p>
            <p class="law">123 Some Ave.<br>
              City, State, Zip Code            </p>
            <p class="law">Database Administrator - You@Your-Email-Address.com</p>
          </div>
          <p>. </p>
          </div>
        </div></td>
    </tr>
  </table>
  <p>&nbsp;</p>
  <p>&nbsp;</p>
  <p>&nbsp;</p>
  <p>&nbsp;</p>
  <p>&nbsp;</p>
</div>
</body>
</html>
  
  
  <?
include("_main.footer.php");
?>
  
  
  
  
