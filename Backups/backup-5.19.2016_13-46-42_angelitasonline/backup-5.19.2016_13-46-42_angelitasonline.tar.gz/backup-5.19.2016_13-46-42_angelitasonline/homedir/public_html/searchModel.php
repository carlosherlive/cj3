<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<script>
if(navigator.userAgent.indexOf("Firefox") != -1)
{
   window.location = "searchModel_ff.php";
}
else
{
   window.location = "searchModel_ie.php";
}
</script>

<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Untitled Document</title>
<style type="text/css">
<!--
body,td,th {
	color: #FFCC00;
}
body {
	background-color: #8F0000;
}
.style2 {font-weight: bold; font-family: Arial, Helvetica, sans-serif;}
-->
</style></head>

<body>

<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p align="center" class="style2">LOADING...</p>

</body>
</html>
