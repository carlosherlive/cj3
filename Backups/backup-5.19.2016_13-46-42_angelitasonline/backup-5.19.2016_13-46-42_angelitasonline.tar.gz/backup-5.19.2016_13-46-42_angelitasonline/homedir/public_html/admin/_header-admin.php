<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" dir="ltr">
<html>

<style type="text/css">
<!--
body,td,th {
	color: #CC0000;
	font-family: Arial, Helvetica, sans-serif;
	font-size: 14px;
	font-weight: bold;
}
body {
	background-color: #FFFFFF;
}
a:link {
	color: #0066FF;
	text-decoration: none;
}
a:visited {
	color: #0066FF;
	text-decoration: none;
}
a:hover {
	color: #000066;
	text-decoration: none;
}
a:active {
	color: #0066FF;
	text-decoration: none;
}
.style3 {font-family: Arial, Helvetica, sans-serif; font-size: 16px; font-weight: bold; color: #666666; }
.style4 {color: #000000}



</style>




<head>
<meta http-equiv="content-type" content="text/html; charset=utf-8" />


<title>Admin Panel</title>

<!-- Start css3menu.com HEAD section -->
	<link rel="stylesheet" href="../admin-bar/admin-style/style.css" type="text/css" /><style type="text/css">._css3m{display:none}</style>
	<!-- End css3menu.com HEAD section -->



<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link href="styles.css" rel="stylesheet" type="text/css">

</head>
<body>
<div class="selector">
<table width="100%" border="0" align="center" cellpadding="0" cellspacing="0" bgcolor="#FFFFFF">
  <tr>
  </tr>
  <tr><br>
    <td align="center"><!-- Start css3menu.com BODY section -->
<ul id="css3menu1" align="center"class=" topmenu">
	<li class="topfirst"><a href="index.php" style="height:32px;line-height:32px;"><img src="../admin-bar/admin-style/001_01.png" alt=""/>Admin Home</a></li>
	<li class="topmenu"><a href="newsubscriptions.php" style="height:32px;line-height:32px;"><img src="../admin-bar/admin-style/001_07.png" alt=""/>Pending Models</a></li>
	<li class="topmenu"><a href="payments.php" style="height:32px;line-height:32px;"><img src="../admin-bar/admin-style/chart.png" alt=""/>Performer Payouts</a></li>
	<li class="topmenu"><a href="#" style="height:32px;line-height:32px;"><span><img src="../admin-bar/admin-style/info.png" alt=""/>Account Admin</span></a>
	<ul>
		<li><a href="members.php"><img src="../admin-bar/admin-style/002.png" alt=""/>Member Accounts</a></li>
		<li><a href="models.php"><img src="../admin-bar/admin-style/performer-icon.png" alt=""/>Performer Accounts</a></li>
	</ul></li>
	<li class="topmenu"><a href="newsletter.php" style="height:32px;line-height:32px;"><img src="../admin-bar/admin-style/001_12.png" alt=""/>Mailing List</a></li>
	<li class="topmenu"><a href="#" style="height:32px;line-height:32px;"><span><img src="../admin-bar/admin-style/service.png" alt=""/>Settings</span></a>
	  <ul>
		<li><a href="configureccbill.php"><img src="../admin-bar/admin-style/1784.png" alt=""/>CC Bill Payment Gateway</a></li>
		<li><a href="package.php"><img src="../admin-bar/admin-style/token-icon.png" alt=""/>Token Packages</a></li>
		<li><a href="categories.php"><img src="../admin-bar/admin-style/categories-icon.png" alt=""/>Categories Setup</a></li>
	</ul></li>
	<li class="toplast"><a href="../index.php" style="height:32px;line-height:32px;"><img src="../admin-bar/admin-style/009.png" alt=""/>Main Site</a></li>
</ul><p class="_css3m"><a href="http://css3menu.com/">Best HTML Menu  Css3Menu.com</a></p>
<!-- End css3menu.com BODY section -->
	
	
	
  </tr>
  <tr>
    <td><p><img src="../graphics/space.gif" width="1" height="1"></p></td>
  </tr>
</table></div>
