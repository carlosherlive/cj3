<?

mail($email, "Account Activation", "Thank you for registering at $siteurl 

In order to activate your newly created account copy and paste the link below in your browser:



$siteurl/actm.php?UID=$userId



Once you activate your membership you will recieve a mail with your login information.



Thanks!

The Webmaster

This is an automated response, please do not reply!","From: youremail");




?>