<?
include("_reg.header.php");
?><style type="text/css">
<!--
body,td,th {
	color: #FFFFFF;
	font-family: Arial, Helvetica, sans-serif;
	font-size: 11px;
	font-weight: bold;
}
body {
	background-color: #8F0000;
}
a {
	font-size: 11px;
	color: #FFFFFF;
}
a:link {
	text-decoration: none;
}
a:visited {
	text-decoration: none;
	color: #FFFFFF;
}
a:hover {
	text-decoration: none;
	color: #FFFFFF;
}
a:active {
	text-decoration: none;
	color: #FFFFFF;
}
-->
</style>

<table width="720" height="400" border="0" align="center" cellpadding="0" cellspacing="0" bgcolor="#8F0000">

  <tr>

    <td align="center" valign="middle"><table width="600" border="0" cellspacing="0" cellpadding="0">

      <tr>

        <td><p class="message">You have sucessfully sent a request to become a model on our site, once an administrator approves your request you will recieve a confirmation email.</p>          </td>

      </tr>

      <tr>

        <td>&nbsp;</td>

      </tr>

    </table>      </td>

  </tr>

</table>

<?
include("_reg.footer.php");
?>
