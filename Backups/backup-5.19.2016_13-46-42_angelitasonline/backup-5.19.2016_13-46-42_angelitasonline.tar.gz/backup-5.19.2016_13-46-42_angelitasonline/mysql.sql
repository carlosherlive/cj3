-- cPanel mysql backup
GRANT USAGE ON *.* TO 'angelita_us548'@'localhost' IDENTIFIED BY PASSWORD '*8B9F00395EBBB09C0ACCCE9CD00B2C8D2FAE2DD4';
GRANT ALL PRIVILEGES ON `angelita\_bd548`.* TO 'angelita_us548'@'localhost';
GRANT USAGE ON *.* TO 'angelitasonline'@'localhost' IDENTIFIED BY PASSWORD '*58B81546559458A20F516ADD51CA60425C940DA2';
GRANT ALL PRIVILEGES ON `angelita\_bd548`.* TO 'angelitasonline'@'localhost';
