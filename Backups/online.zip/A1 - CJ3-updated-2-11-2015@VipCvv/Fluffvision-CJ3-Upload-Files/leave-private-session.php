<?
include("_main.header.php");
?>

<?
include("dbase.php");

include("settings.php");


echo "<META HTTP-EQUIV=\"Refresh\"
CONTENT=\"5; URL=index.php\">";



?>


<style type="text/css">
<!--
body,td,th {
	color: #FFFFFF;
	font-family: Arial, Helvetica, sans-serif;
	font-size: 11px;
	font-weight: regular;
}

}
.please-wait-text {color: #ffffff}
#Layer1 {
	position:absolute;
	width:145px;
	height:115px;
	z-index:1;
	left: 508px;
	top: 811px;
}

-->
</style>

<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<table width="1100" height="600" border="0" align="center" cellpadding="0" cellspacing="0" background="images/end-of-show-bg.png">

  <tr>

    <td height="377" align="center" valign="middle"><table width="522" border="0" cellspacing="0" cellpadding="0">
      <tr>
        <td width="361"><h3 align="center" class="please-wait-text">&nbsp;</h3>
          <div align="center">
  
</div></p></td>
      </tr>
      <tr>
        
      </tr>
    </table>
    <br />
   </td>

  </tr>
</table>


<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>

<?
include("_main.footer.php");
?>
