<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Password Sent</title>
<?
include("_main.header.php");
?><style type="text/css">
<!--
body,td,th {
	color: #FFFFFF;
}
body {
	background-color: #8F0000;
}
a:link {
	color: #FFFFFF;
}
a:visited {
	color: #FF9900;
}
a:hover {
	color: #FF9900;
}
a:active {
	color: #FF9900;
}
.style1 {font-family: Arial, Helvetica, sans-serif}
-->
</style></head>

<body>
<div align="center">
  <p>&nbsp;</p>
  <p>&nbsp;</p>
  <table width="100%" border="0" bgcolor="#8F0000">
    <tr>
      <td><div align="center" class="style1">
        <p>Your password has been reset. You should receive an email shortly.</p>
        <p><a href="login.php" target="_self">Click Here to login.</a> </p>
      </div></td>
    </tr>
  </table>
  <p>&nbsp;</p>
</div>
</body>
</html>
<?
include("_main.footer.php");
?>