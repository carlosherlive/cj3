<?
//Example FMS RTMP String. Replace this RTMP address with yours as listed in the setup instructions.//
$connection_string="rtmp://your-flash-URL.com/your-flash-folder-name-here/";

$sitename="CJ3";

$copyright="FLUFFVISION";

$copyrightYear="2014";

//site url
$siteurl="http://your-domain.com";

//used in registration mails, payment mails...Replace these with your email address...//
$registrationemail="support@fluffvision.com";
$feedbackemail="support@fluffvision.com";
$paymentemail="support@fluffvision.com";

//used for favorites announcements
$contactemail="support@fluffvision.com";
$newsletteremail="support@fluffvision.com";

//NOT IN USE IN THIS VERSION//
$freehours=1;

//NOT IN USE IN THIS VERSION//
$sopepercentage=10;


//NOT IN USE IN THIS VERSION- CATEGORIES ARE CREATED FROM THE ADMIN PANEL//
$cat1="Girls";
$cat2="Boys";
$cat3="Empty Category";
$cat4="Empty Category";
$cat5="Empty Category";
$cat6="Empty Category";
$cat7="Empty Category";
$cat8="Empty Category";
$cat9="Empty Category";
$cat10="Empty Category";
$cat11="Empty Category";
$cat12="Empty Category";
$cat13="Empty Category";
$cat14="Empty Category";
$cat15="Empty Category";
$cat16="Empty Category";
$cat17="Empty Category";
$cat18="Empty Category";
$cat19="Empty Category";
$cat20="Empty Category";
$cat21="Empty Category";
$cat22="Empty Category";
$cat23="Empty Category";
$cat24="Empty Category";
$cat25="Empty Category";
$cat26="Empty Category";
$cat27="Empty Category";
$cat28="Empty Category";
$cat29="Empty Category";
$cat30="Empty Category";


//DO NOT EDIT BELOW THIS LINE.
/////////////////////////////



//NOT IN USE IN THIS VERSION//
$displayofflinemodels=0;
$offlinemodelslines=4;
$paymentday=13;
$freechattime=66666120;
$moviequality=100;
$moviebandwith=12000;
?>