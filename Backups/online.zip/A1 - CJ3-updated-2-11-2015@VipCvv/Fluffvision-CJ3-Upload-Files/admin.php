<?
include("_main.header.php");

?>


<title>Untitled Document</title>
<style type="text/css">
<!--
body,td,th {
	color: #FFFFFF;
}
body {
	background-color: #8F0000;
}
.style1 {
	font-family: Arial, Helvetica, sans-serif;
	font-weight: bold;
	color: #FFFFFF;
	font-size: 12px;
}
.style3 {color: #FFCC00}
-->
</style></head>

<body>
<div align="center">
  <p>&nbsp;</p>
  <p>&nbsp;</p>
  <table width="720" border="0" cellspacing="0" cellpadding="0">
    <tr>
      <td><div align="center" class="style1">
        <p>YOU CAN CONTACT AN ADMIN WITH THE FOLLOWING:</p>
        <p>Your email, telephone number or any other contact informations here.  </p>
      </div></td>
    </tr>
  </table>
  <p>&nbsp;</p>
</div>
</body>
</html>
<?
include("_main.footer.php");
?>