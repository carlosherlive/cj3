
<style type="text/css">
<!--


.selector
{
  /*background-image: url();*/
  background-color: #FFFFFF;
  
  position: fixed;
  
  top: 0;
  left: 0;
  width: 100%;
  height: 40px;
  z-index: 10;

}


body {
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
	margin-bottom: 0px;
}


-->

</style>



<table width="100%" height="73" border="0" align="center" cellpadding="0" cellspacing="0" class="left">
  <tr>
    <td><div align="center">
      <p><a href="../index.php" class="a_left"></a></p>
    </div></td>
  </tr>
</table>
</body>
</html>
