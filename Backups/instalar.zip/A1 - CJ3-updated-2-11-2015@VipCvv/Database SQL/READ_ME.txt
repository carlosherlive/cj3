The SQL file named "CJ3-Database-5-models-final.sql" will install 5 premade performer accounts into your database.

The SQL file named "CJ3-Database-50-models-final.sql"
will install 50 premade performer accounts into your database.
by default the script displays 50 performer thumbnails per page.