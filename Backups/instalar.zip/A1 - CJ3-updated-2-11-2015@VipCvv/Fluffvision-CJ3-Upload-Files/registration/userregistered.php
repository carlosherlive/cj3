<?
include("_reg.header.php");
?><style type="text/css">
<!--
body,td,th {
	color: #FFFFFF;
	font-family: Arial, Helvetica, sans-serif;
	font-size: 14px;
}
body {
	background-color: #8F0000;
}
a:link {
	color: #99CC00;
	text-decoration: none;
}
a:visited {
	text-decoration: none;
	color: #99CC00;
}
a:hover {
	text-decoration: none;
	color: #99FF00;
}
a:active {
	text-decoration: none;
	color: #99CC00;
}
-->
</style>

<table width="720" height="400" border="0" align="center" cellpadding="0" cellspacing="0" bgcolor="#8F0000">

  <tr>

    <td align="center" valign="middle"><table width="600" border="0" cellspacing="0" cellpadding="0">

      <tr>

        <td height="51"><p class="message"> Thank you for registering. </p>

          <p class="message">We have just sent you an activation email. You must visit the activation link in the email to activate your member account. </p>

          </td>

      </tr>

      <tr>

        <td>&nbsp;</td>

      </tr>

    </table>      </td>

  </tr>

</table>
<?
include("_reg.footer.php");
?>
